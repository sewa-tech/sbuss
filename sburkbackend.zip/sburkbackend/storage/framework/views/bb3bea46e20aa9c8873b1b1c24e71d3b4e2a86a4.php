<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<?php $__env->startSection('content'); ?>

    <razorpay razorpay_key_id=<?php echo e($razorpay_key_id); ?> 
    order_id=<?php echo e($order_id); ?> 
    email=<?php echo e($email); ?>></razorpay>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/profile/razor_pay.blade.php ENDPATH**/ ?>