<?php $__env->startSection('auth'); ?>
<?php 
$system_name = App\Setting::where('name', 'System name')->first()->value;
?>
<div class="col-md-8">
    <div class="card-group">
        <div class="card">
            <div class="card-body p-5">
                <a class="text-center d-lg-none" href="<?php echo e(url('/')); ?>">
                    
                    <h2 class="logo-text yellow pb-5"><?php echo e($system_name); ?></h2>
                </a>
                <h3><?php echo e(__('Login')); ?></h3>
                <p class="text-muted">Sign In to your school account</p>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fas fa-envelope-square"></i>
                            </span>
                        </div>
                        <input id="email" type="email" 
                        class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" 
                        name="email" value="<?php echo e(old('email')); ?>" 
                        placeholder="<?php echo e(__('Admin Email Address')); ?>" required autofocus>

                        <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                        </div>
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>

                        <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        </div>
                        <label class="form-check-label" for="remember">
                            <?php echo e(__('Remember Me')); ?>

                        </label>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <button type="submit" class="btn btn-primary px4">
                                <?php echo e(__('Login')); ?>

                            </button>
                        </div>
                        <div class="col-8 text-right">
                            <a class="btn btn-link px-0" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot Your Password?')); ?>

                            </a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer p-4 d-lg-none">
                <div class="col-12 text-right">
                    <a class="btn btn-outline-primary btn-block mt-3" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </div>
            </div>
        </div>
        <div class="card text-white header d-md-down-none">
            <div class="card-body text-center">
                <div>
                    <a href="<?php echo e(url('/')); ?>">
                        <h2 class="logo-text yellow py-5"><?php echo e($system_name); ?></h2>
                    </a>
                    
                    <h4><?php echo e(__('Sign up')); ?></h4>
                    <p>If you don't have account create one.</p>
                    <a class="btn btn-primary mt-2" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register Now!')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/auth/login.blade.php ENDPATH**/ ?>