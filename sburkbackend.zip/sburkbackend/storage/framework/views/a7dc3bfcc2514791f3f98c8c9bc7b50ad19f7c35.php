<?php $__env->startSection('content'); ?>

<sadmin_dashboard></sadmin_dashboard>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/sadmin_dashboard.blade.php ENDPATH**/ ?>