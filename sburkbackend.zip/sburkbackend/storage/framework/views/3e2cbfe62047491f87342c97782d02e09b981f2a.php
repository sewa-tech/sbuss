<?php $__env->startSection('auth'); ?>
<div class="col-md-6">
    <div class="card mx-4">
        <div class="card-body p-4">
            <h3><?php echo e(__('Register Your School')); ?></h3>
            <p class="text-muted">Create your school account</p>

            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="nav-icon fas fa-landmark"></i>
                        </span>
                    </div>
                    <input id="name" type="text" 
                    class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" 
                    name="name" value="<?php echo e(old('name')); ?>"  
                    placeholder="<?php echo e(__('School Name')); ?>" required autofocus>

                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-envelope-square"></i>
                        </span>
                    </div>
                    <input id="email" type="email" 
                    class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" 
                    name="email" value="<?php echo e(old('email')); ?>" 
                    placeholder="<?php echo e(__('Admin Email Address')); ?>" required>

                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-phone"></i>
                        </span>
                    </div>
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            +
                        </span>
                    </div>
                    <input id="country_code" type="text"
                        class="form-control<?php echo e($errors->has('country_code') ? ' is-invalid' : ''); ?>" 
                        name="country_code" value="<?php echo e(old('country_code')); ?>" 
                        placeholder="<?php echo e(__('Country Code')); ?>" required>
                    <input id="tel_number" type="text"
                        class="form-control<?php echo e($errors->has('tel_number') ? ' is-invalid' : ''); ?>" 
                        name="tel_number" value="<?php echo e(old('tel_number')); ?>" 
                        placeholder="<?php echo e(__('Telephone Number')); ?>" required>

                        <?php if($errors->has('country_code')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('country_code')); ?></strong>
                            </span>
                        <?php endif; ?>
                        
                        <?php if($errors->has('tel_number')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('tel_number')); ?></strong>
                            </span>
                        <?php endif; ?>

                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-lock"></i>
                        </span>
                    </div>
                    <input id="password" type="password" 
                    class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"  
                    placeholder="<?php echo e(__('Password')); ?>" name="password" required>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-lock"></i>
                        </span>
                    </div>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="<?php echo e(__('Confirm Password')); ?>" required>
                </div>

                <button type="submit" class="btn btn-block btn-success btn-primary">
                    <?php echo e(__('Create Account')); ?>

                </button>
            </form>
        </div>
        <div class="card-footer p-4">
            <div class="row">
                <div class="col-12">
                    <a class="btn btn-outline-primary btn-block" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/auth/register.blade.php ENDPATH**/ ?>