<script src="https://js.stripe.com/v3/"></script>
<?php $__env->startSection('content'); ?>
    <stripepay stripe_publishable_key=<?php echo e($stripe_publishable_key); ?> 
    client_secret=<?php echo e($client_secret); ?>></stripepay>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/profile/stripe_pay.blade.php ENDPATH**/ ?>