<?php $__env->startSection('content'); ?>
    <plans-create></plans-create>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/plans/create.blade.php ENDPATH**/ ?>