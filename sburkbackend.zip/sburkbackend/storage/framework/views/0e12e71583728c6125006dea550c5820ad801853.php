<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($GOOGLE_MAPS_API_KEY); ?>&libraries=places&callback="></script>
<?php $__env->startSection('content'); ?>

<school></school>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/school/school.blade.php ENDPATH**/ ?>