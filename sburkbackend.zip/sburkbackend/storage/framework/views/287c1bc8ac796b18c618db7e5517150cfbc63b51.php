<?php $__env->startSection('content'); ?>
    <?php
    $school = auth()->user();
    $current_children = 0;;
    for ($x = 0; $x < $school->parents->count(); $x++) {
        for ($y = 0; $y < $school->parents[$x]->children->count(); $y++) {
            $current_children++;
        }
    }
    ?>
    <parents-edit v-bind:maximum="<?php echo e(auth()->user()->plan->allowed_children-$current_children); ?>"></parents-edit>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/parents/edit.blade.php ENDPATH**/ ?>