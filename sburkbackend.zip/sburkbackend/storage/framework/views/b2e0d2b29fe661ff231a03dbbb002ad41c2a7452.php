<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
        <?php if(auth()->user()->is_super_admin_account): ?>
            <li class="nav-item">
                <a class="nav-link" href="/sadmin_dashboard">
                    <i class="nav-icon fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/schools">
                    <i class="nav-icon fas fa-landmark"></i> Schools
                </a>
            </li>

            
            <li class="nav-item">
                <a class="nav-link" href="/plans">
                    <i class="nav-icon far fa-handshake"></i> Plans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/custom-plans">
                    <i class="nav-icon fas fa-drafting-compass"></i> Custom Plans
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="/settings">
                    <i class="nav-icon fas fa-tools"></i> Settings
                </a>
            </li>
            <!-- <li class="nav-item">
                <a class="nav-link" href="/activation">
                    <i class="nav-icon fas fa-charging-station"></i> Activation
                </a>
            </li> -->

            <li class="nav-item">
                <a class="nav-link" href="/privacy-policy">
                    <i class="nav-icon fas fa-lock"></i> Privacy Policy
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/terms">
                    <i class="nav-icon fas fa-allergies"></i> Terms & Conditions
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/ios-products">
                    <i class="nav-icon fab fa-apple"></i> iOS Products
                </a>
            </li>
        <?php else: ?> 
            <li class="nav-item">
                <a class="nav-link" href="/dashboard">
                    <i class="nav-icon fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/school">
                    <i class="nav-icon fas fa-landmark"></i> School
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/drivers">
                    <i class="nav-icon fas fa-user-tie"></i> Drivers
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/parents">
                    <i class="nav-icon fas fa-users"></i> Parents
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/buses">
                    <i class="nav-icon fas fa-bus-alt"></i> Buses
                </a>
            </li>
        <?php endif; ?>   
            <li class="nav-title">
                <div>Current time</div>
                <div><?php echo e(date("Y-m-d H:i:s", time() - date("Z"))); ?></div>
            </li>
            <?php $now = time();
            $nextResetTime = date("Y-m-d H:i:s", $now + (3600 - $now % 3600)); ?>
            <li class="nav-title">
                <div style="color:red;">Database reset at</div>
               <div style="color:red;"><?php echo e($nextResetTime); ?></div>
            </li>             
        </ul>

    </nav>
    <sidebar></sidebar>
</div>
<?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>