<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Driver::class)): ?>
        <drivers-index v-bind:can-create-driver="true"></drivers-index>
    <?php else: ?>
        <drivers-index v-bind:can-create-driver="false"></drivers-index>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/drivers/index.blade.php ENDPATH**/ ?>