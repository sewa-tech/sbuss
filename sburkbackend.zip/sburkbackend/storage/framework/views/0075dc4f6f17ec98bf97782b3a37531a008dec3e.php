<?php $__env->startSection('content'); ?>
    <?php 
    if($can_create) {?>
        <plans-index :can_create_plan=true></plans-index>
    <?php } else { ?>
        <plans-index :can_create_plan=false></plans-index>
    <?php } ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/plans/index.blade.php ENDPATH**/ ?>