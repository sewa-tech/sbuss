<?php $__env->startSection('content'); ?>
    <?php 
    if($can_create) {?>
        <schools-index :can_create_school=true></schools-index>
    <?php } else { ?>
        <schools-index :can_create_school=false></schools-index>
    <?php } ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dev/Documents/Projects/sburkbackend/resources/views/schools/index.blade.php ENDPATH**/ ?>