@extends('layouts.app')

@section('content')
    <buses-index></buses-index>
@endsection
