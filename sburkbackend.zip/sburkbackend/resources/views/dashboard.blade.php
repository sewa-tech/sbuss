@extends('layouts.app')

@section('content')

<dashboard></dashboard>

@endsection
