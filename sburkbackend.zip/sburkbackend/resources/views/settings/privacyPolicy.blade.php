@extends('layouts.app')

@section('content')

<privacy-policy></privacy-policy>

@endsection
