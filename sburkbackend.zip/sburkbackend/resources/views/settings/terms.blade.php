@extends('layouts.app')

@section('content')

<terms></terms>

@endsection
