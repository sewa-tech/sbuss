@extends('layouts.app')

@section('content')

<settings></settings>

@endsection
