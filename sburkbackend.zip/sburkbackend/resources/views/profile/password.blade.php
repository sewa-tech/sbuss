@extends('layouts.app')

@section('content')
    <profile-password></profile-password>
@endsection
