@extends('layouts.app')

@section('content')
    <plan></plan>
@endsection
