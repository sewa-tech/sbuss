@extends('layouts.app')

@section('content')

<sadmin_dashboard></sadmin_dashboard>

@endsection
