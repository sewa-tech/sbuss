@extends('layouts.app')

@section('content')
<products-index></products-index>
@endsection
