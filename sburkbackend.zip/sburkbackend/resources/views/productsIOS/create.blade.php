@extends('layouts.app')

@section('content')
    <products-create></products-create>
@endsection
