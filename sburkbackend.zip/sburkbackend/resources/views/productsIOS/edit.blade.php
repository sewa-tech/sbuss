@extends('layouts.app')

@section('content')
    <products-edit></products-edit>
@endsection
