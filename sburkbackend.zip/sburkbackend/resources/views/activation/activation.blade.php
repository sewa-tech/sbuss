@extends('layouts.app')

@section('content')

<activation></activation>

@endsection
