@extends('layouts.app')

@section('content')
<custom-plans-index></custom-plans-index>
@endsection
