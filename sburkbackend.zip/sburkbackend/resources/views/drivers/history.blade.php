@extends('layouts.app')

@section('content')
    <drivers-history></drivers-history>
@endsection
