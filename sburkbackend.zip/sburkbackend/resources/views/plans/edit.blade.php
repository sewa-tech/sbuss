@extends('layouts.app')

@section('content')
    <plans-edit></plans-edit>
@endsection
