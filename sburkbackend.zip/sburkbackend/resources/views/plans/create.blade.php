@extends('layouts.app')

@section('content')
    <plans-create></plans-create>
@endsection
