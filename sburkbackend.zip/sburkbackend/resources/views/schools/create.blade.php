@extends('layouts.app')

@section('content')
    <schools-create></schools-create>
@endsection
