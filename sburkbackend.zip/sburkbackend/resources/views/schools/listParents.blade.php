@extends('layouts.app')

@section('content')
    <schools-list-parents></schools-list-parents>
@endsection
