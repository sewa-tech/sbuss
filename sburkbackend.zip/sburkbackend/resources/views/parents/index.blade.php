@extends('layouts.app')



@section('content')
    <parents-index></parents-index>
@endsection
