<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomPlanSetting extends Model
{
    //

    protected $guarded = ['id'];
}
