<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DriverZoneVisit extends Model
{
    //
    protected $table = 'driver_zone_visits';
}
