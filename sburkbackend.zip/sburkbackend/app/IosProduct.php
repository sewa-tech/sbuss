<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IosProduct extends Model
{
    //
    protected $guarded = ['id'];
}
